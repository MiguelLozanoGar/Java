/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.empresa.deporte;

/**
 *
 * @author Tecnicos
 */
public class Jugador {
    //propiedades
    int id;
    String nombre;
    float goles;
    boolean titular;
    
    //constructor
//insert 
    public Jugador(int id, String nombre, float goles, boolean titular) {
        this.id = id;
        this.nombre = nombre;
        this.goles = goles;
        this.titular = titular;
    }
//getter --- select
    public int getId() {
        return id;
    }
//setter --update, delete
    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getGoles() {
        return goles;
    }

    public void setGoles(float goles) {
        this.goles = goles;
    }

    public boolean isTitular() {
        return titular;
    }

    public void setTitular(boolean titular) {
        this.titular = titular;
    }

    @Override //sobreescritura NO sobrecarga
    public String toString() {
        return "Jugador{" + "id=" + id + ", nombre=" + nombre + ", goles=" + goles + ", titular=" + titular + '}';
    }
    
    
}//cierra clase
