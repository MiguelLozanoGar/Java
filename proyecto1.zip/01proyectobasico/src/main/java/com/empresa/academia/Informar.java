/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.empresa.academia;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Tecnicos
 */
public class Informar {
    public static void main(String[] args){
        Alumno alumno1=new Alumno(1, "marta sánchez", 8, new Date());
        Alumno alumno2=new Alumno(2, "luis lópez", 4, new Date());
        Alumno alumno3=new Alumno(3, "laura pérez", 7, new Date());
        
        ArrayList aula9= new ArrayList();
        aula9.add(alumno1);
        aula9.add(alumno2);
        aula9.add(alumno3);
        
        for(Object a:aula9){
        System.out.println(a.toString());
        }
        
        
    }//cierra main
}//cierra clase
