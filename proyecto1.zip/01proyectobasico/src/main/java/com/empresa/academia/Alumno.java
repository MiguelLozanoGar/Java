/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.empresa.academia;

import java.util.Date;

/**
 *
 * @author Tecnicos
 */
public class Alumno {
    int id_alumno;
    String nombre;
    int calificacion;
    Date fecha_matricula;

    public Alumno(int id_alumno, String nombre, int calificacion, Date fecha_matricula) {
        this.id_alumno = id_alumno;
        this.nombre = nombre;
        this.calificacion = calificacion;
        this.fecha_matricula = fecha_matricula;
    }

    public int getId_alumno() {
        return id_alumno;
    }

    public void setId_alumno(int id_alumno) {
        this.id_alumno = id_alumno;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(int calificacion) {
        this.calificacion = calificacion;
    }

    public Date getFecha_matricula() {
        return fecha_matricula;
    }

    public void setFecha_matricula(Date fecha_matricula) {
        this.fecha_matricula = fecha_matricula;
    }

    @Override
    public String toString() {
        return "Alumno{" + "id_alumno=" + id_alumno + ", nombre=" + nombre + ", calificacion=" + calificacion + ", fecha_matricula=" + fecha_matricula + '}';
    }
    
    
}//cierra clase
