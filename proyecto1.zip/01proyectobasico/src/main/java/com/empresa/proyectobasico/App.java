/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.empresa.proyectobasico;

import com.empresa.deporte.Jugador;

/**
 *
 * @author Tecnicos
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        String mensaje="un mensaje de ejemplo";
        int letras=mensaje.length();
        System.out.println("el mensaje tiene "+letras+" letras");
        double aleatorio=Math.random();
        double numero_generado=aleatorio*100;
        System.out.println("el número generado es "+numero_generado);
        boolean descuento=true;
        if(descuento){
            System.out.println("Aplicamos descuento");
        }//cierra if
        else{
        System.out.println("No tiene descuento");
        }
        
        //implementar la clase : crear un objeto
        Jugador jugador=new Jugador(100, "curtuá", 20.54f, true);
        System.out.println(jugador.toString());
    }//cierra main
}//cierra clase

