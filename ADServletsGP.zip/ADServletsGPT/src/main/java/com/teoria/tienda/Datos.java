package com.teoria.tienda;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Datos
 */
@WebServlet("/Datos")
public class Datos extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Datos() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		

		
		    Connection conn = null;
		    try {
		    	Class.forName("com.mysql.cj.jdbc.Driver");
		      // Establecer la conexión con la base de datos
		      conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "");
		      
		      // Crear una sentencia SQL para insertar un registro en la tabla 'producto'
		      String insertSQL = "INSERT INTO productos (id, nombre, unidades, precio) VALUES (?, ?, ?, ?)";
		      
		      // Crear un objeto PreparedStatement para ejecutar la sentencia SQL
		      PreparedStatement pstmt = conn.prepareStatement(insertSQL);
		      pstmt.setString(1, request.getParameter("id")); // establecemos el valor del primer parámetro (id) a 1
		      pstmt.setString(2, request.getParameter("nombre")); // establecemos el valor del segundo parámetro (nombre) a "Producto 1"
		      pstmt.setString(3, request.getParameter("unidades")); // establecemos el valor del tercer parámetro (unidades) a 10
		      pstmt.setString(4, request.getParameter("precio")); // establecemos el valor del cuarto parámetro (precio) a 19.99
		      pstmt.executeUpdate(); // Ejecutar la sentencia SQL
		      
		      System.out.println("Registro insertado correctamente en la tabla producto.");
		    } catch (SQLException e) {
		      System.out.println("Error al insertar el registro en la tabla producto: " + e.getMessage());
		    } catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
		      // Cerrar la conexión con la base de datos
		      if (conn != null) {
		        try {
		          conn.close();
		        } catch (SQLException e) {
		          System.out.println("Error al cerrar la conexión con la base de datos: " + e.getMessage());
		        }
		      }
		    }
		  
		

		
		
	}

}
