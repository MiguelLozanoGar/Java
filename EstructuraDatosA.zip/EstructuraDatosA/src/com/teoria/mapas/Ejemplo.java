package com.teoria.mapas;

import java.util.HashMap;

public class Ejemplo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//tabla Clientes pk AI-identity :index : List / Set
		//tabla Clientes pk NO AI-dni :key : Map
				
		//interfaz Map : no tiene index, y sí tiene key
		
		//HashMap
		HashMap<String, Cliente>hm=new HashMap<>();
		hm.put("123m", new Cliente("juan", "madrid"));
		hm.put("258s", new Cliente("marta", "córdoba"));
		hm.put("325r", new Cliente("juan", "sevilla"));
		hm.put("965y", new Cliente("laura", "madrid"));
		
		hm.forEach((k,v)->System.out.println(v.getNombre()));
		
		//TreeMap-nodos
		
		//HashTable - HT-concurrente - thread-safe
		
	}//cierra main

}//cierra class
