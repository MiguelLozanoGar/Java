package com.teoria.conjuntos;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class Ejemplo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//interfaz conjuntos Set - no admite duplicados
		
		//HashSet --mejor para insert, update, delete. peor rendimiento para select
		//muestra elementos ordenados en base a un hash (NO en base a index)
		//InnoDb
		System.out.println("HashSet");
		HashSet<String>hs=new HashSet<>();
		hs.add("madrid");
		hs.add("sevilla");
		hs.add("madrid");
		hs.add("córdoba");
		
		hs.forEach(item->System.out.println(item));
		
		//LinkedHashSet --mejor rendimiento para select
		System.out.println("LinkedHashSet");
		LinkedHashSet<String>lhs=new LinkedHashSet<>();
		lhs.add("madrid");
		lhs.add("sevilla");
		lhs.add("madrid");
		lhs.add("córdoba");
		
		lhs.forEach(item->System.out.println(item));
		//myISAM
						
		//TreeSet - Nodos - XML - criterio de ordenación basado en Tree : multinivel
		
	}//cierra main

}//cierra class
