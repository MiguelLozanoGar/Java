package com.teoria.listas;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Vector;

public class Ejemplo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//interfaz List que será implementada por las tres.
		//utilizas index : ai mysql
		
		//ArrayList : no sincronizado - con hilos tiene lock - resize - admite duplicados - tipado fuerte
		//muestra orden en base al index 0123...
		ArrayList<Integer>lista=new ArrayList<>();
		lista.add(15);
		lista.add(20);
		lista.add(15);
		//recorrer AL con programación funcional
		lista.forEach(item->{System.out.println(item);});
		lista.remove(2);
		lista.forEach(item->{System.out.println(item);});
		
		//Vector : similar AL pero admite concurrencia. multihilo
		System.out.println("Vector");
		Vector<Integer>vector=new Vector<>();
		vector.add(15);
		vector.add(20);
		vector.add(15);
		//recorrer AL con programación funcional
		vector.forEach(item->{System.out.println(item);});
		vector.remove(2);
		vector.forEach(item->{System.out.println(item);});
		
		//LinkedList : enlaza los elementos. peor rendimiento al insert/update/delete pero mejor rendimiento con select
		System.out.println("Linked List");
		LinkedList<Integer>lista_enlazada=new LinkedList<>();
		lista_enlazada.add(15);
		lista_enlazada.add(20);
		lista_enlazada.add(15);
		//recorrer AL con programación funcional
		lista_enlazada.forEach(item->{System.out.println(item);});
		lista_enlazada.remove(2);
		lista_enlazada.forEach(item->{System.out.println(item);});
		
		
	}//cierra main

}//cierra class
