package com.teoria.cuarto;

public class Ejecutar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Modificador modificador=new Modificador();
		modificador.saludar3();
	}

}
