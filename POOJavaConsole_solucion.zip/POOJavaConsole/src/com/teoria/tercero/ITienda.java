package com.teoria.tercero;

public interface ITienda {

	public void registrar();
	public void comprar();
	public void addCarrito(String articulo);
	public void pagar();
}
