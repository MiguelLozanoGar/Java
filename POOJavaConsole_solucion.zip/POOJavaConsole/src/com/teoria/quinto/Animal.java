package com.teoria.quinto;

public class Animal {
	//NO se usará porque está sobreescrito en las hijas - override
	public void comer() {
		System.out.println("el animal come");
	}
}
