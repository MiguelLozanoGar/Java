package com.teoria.quinto;

public class Perro extends Animal {

	public void comer() {
		System.out.println("el perro come hueso");
	}
}
