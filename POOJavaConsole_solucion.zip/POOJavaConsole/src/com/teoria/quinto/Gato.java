package com.teoria.quinto;

public class Gato extends Animal {//permite polimorfismo

	public void comer() {
		System.out.println("el gato come leche");
	}
}
